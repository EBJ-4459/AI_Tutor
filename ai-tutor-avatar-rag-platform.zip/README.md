# AI Tutor Platform (3D Avatar + RAG Knowledge Base + Attention Checker)

An interactive, multi-modal AI Tutoring platform that combines:
1. **Interactive 3D Avatar (Partition 1)**: Powered by TalkingHead WebGL with realistic facial expressions, camera view switching, and real-time lip-synced Edge-TTS voice.
2. **Interactive Tutoring Chat (Partition 2)**: Gemini streaming conversation with citations, speech-to-text input, and automatic distraction alerts.
3. **Document Knowledge Base (Partition 3)**: Upload PDF/TXT/MD textbooks with semantic chunking and ChromaDB local vector retrieval.
4. **Visual Attention & Drowsiness Checker (Port 8001)**: Background MediaPipe head pose & EAR tracking that cues the avatar to speak (*"Pay attention here!"*) if the student looks away, appears drowsy, or steps away.

---

## ⚡ Super Easy Setup (For Beginners)

### Step 1: Requirements
Before running, make sure your computer has:
1. **Python (3.10 or 3.11)**: [Download from python.org](https://www.python.org/downloads/)
   * **Important**: Check the box that says **"Add Python to PATH"** during installation.
2. **Node.js (LTS version)**: [Download from nodejs.org](https://nodejs.org/)

---

### Step 2: One-Click Installation
1. Unzip the project folder anywhere on your computer.
2. Double-click **`install.bat`**.
   * It will automatically install all Python backend packages and Node.js frontend packages.

---

### Step 3: Add Your Gemini API Key
1. Open the file `avatar-chatbot/backend/.env` with Notepad (or any text editor).
2. Set your free Google Gemini API key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
   *(You can generate a free key in seconds at: https://aistudio.google.com/)*

---

### Step 4: Launch!
Double-click **`run_local.bat`**!

It automatically starts all 3 services and opens your browser:
- **Main 3-Partition Tutor UI**: [http://localhost:5173](http://localhost:5173)
  - **Partition 1**: 3D Avatar
  - **Partition 2**: Interactive Chat with Voice & Citations
  - **Partition 3**: Upload & Manage Textbooks/Documents
- **Attention Checker HUD (Port 8001)**: [http://localhost:8001](http://localhost:8001)
  - Live webcam, 3D head pose yaw, and Eye Aspect Ratio (EAR) gauges
- **Backend API**: [http://localhost:8000](http://localhost:8000)

---

## 💡 How It Works
- **Studying & Asking Questions**: Type or speak using the microphone. The avatar speaks the explanation out loud with lip-sync.
- **Uploading Materials**: Upload lecture notes or textbooks in Partition 3. When you ask questions, the tutor references and cites your materials.
- **Attention Monitoring**: Keep the Attention Checker open on Port 8001. If you turn your head away or your eyes close for several seconds, the 3D avatar immediately interrupts with a spoken reminder: *"Hey, I noticed you got distracted! Pay attention here, let's stay focused on our lesson!"*
